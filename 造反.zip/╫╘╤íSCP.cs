﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Exiled.API.Enums;
using Exiled.API.Features;
using Exiled.API.Features.Items;
using Exiled.API.Features.Pickups;
using Exiled.API.Interfaces;
using Exiled.Events.EventArgs.Player;
using Exiled.Events.EventArgs.Server;
using MEC;
using PlayerRoles;
using UnityEngine;

namespace ClassDRebellionIndicator
{
    public class RebellionSystem : Plugin<RebellionSystem.PluginConfig>
    {
        public static RebellionSystem Instance { get; private set; }
        public override string Name => "ClassDRebellionIndicator";
        public override string Author => "YourName";
        public override Version Version => new Version(1, 2, 1);
        public override PluginPriority Priority => PluginPriority.Medium;

        private Dictionary<Player, RebellionData> _rebellionData = new Dictionary<Player, RebellionData>();
        private Dictionary<Player, CoroutineHandle> _statusHandles = new Dictionary<Player, CoroutineHandle>();

        private HashSet<ItemType> _contrabandItems = new HashSet<ItemType>
        {
            ItemType.GunCOM15,
            ItemType.GunCOM18,
            ItemType.GunE11SR,
            ItemType.GunCrossvec,
            ItemType.GunFSP9,
            ItemType.GunLogicer,
            ItemType.GunRevolver,
            ItemType.GunShotgun,
            ItemType.GunAK,
            ItemType.GunCom45
        };

        public class PluginConfig : IConfig
        {
            [Description("Whether the plugin is enabled")]
            public bool IsEnabled { get; set; } = true;

            [Description("Debug mode")]
            public bool Debug { get; set; } = false;

            [Description("Points required to riot")]
            public int RebellionThreshold { get; set; } = 200;

            [Description("Suspicion threshold")]
            public int SuspicionThreshold { get; set; } = 100;

            [Description("Points for picking up contraband")]
            public int PickupContrabandPoints { get; set; } = 100;

            [Description("Points per second for holding contraband")]
            public int HoldingContrabandPerSecond { get; set; } = 2;

            [Description("Points per second for nearby contraband")]
            public int NearbyContrabandPerSecond { get; set; } = 2;

            [Description("Points per nearby D-Class/Chaos damaging Foundation")]
            public int NearbyRebelDamagePoints { get; set; } = 20;

            [Description("Points for D-Class damaging Foundation faction")]
            public int DealDamageToFoundationPoints { get; set; } = 999;

            [Description("Points reduction per second without contraband")]
            public int NoContrabandReductionPerSecond { get; set; } = 2;
        }

        public class RebellionData
        {
            public int RebellionPoints { get; set; } = 0;
            public bool HasRebelled { get; set; } = false;
            public string OriginalNickname { get; set; } = string.Empty;
            public bool IsClassD { get; set; } = false;
            public int LastDisplayedPoints { get; set; } = -1;
            public string LastSuffix { get; set; } = string.Empty;
        }

        public override void OnEnabled()
        {
            Instance = this;

            Exiled.Events.Handlers.Player.Verified += OnPlayerVerified;
            Exiled.Events.Handlers.Player.ChangingRole += OnPlayerChangingRole;
            Exiled.Events.Handlers.Player.Destroying += OnPlayerDestroying;
            Exiled.Events.Handlers.Player.PickingUpItem += OnPickingUpItem;
            Exiled.Events.Handlers.Player.DroppingItem += OnDroppingItem;
            Exiled.Events.Handlers.Player.Hurting += OnHurting;
            Exiled.Events.Handlers.Server.RoundEnded += OnRoundEnded;
            Exiled.Events.Handlers.Server.RestartingRound += OnRoundRestarting;

            Log.Info("Class-D Riot Indicator has been enabled!");
        }

        public override void OnDisabled()
        {
            Exiled.Events.Handlers.Player.Verified -= OnPlayerVerified;
            Exiled.Events.Handlers.Player.ChangingRole -= OnPlayerChangingRole;
            Exiled.Events.Handlers.Player.Destroying -= OnPlayerDestroying;
            Exiled.Events.Handlers.Player.PickingUpItem -= OnPickingUpItem;
            Exiled.Events.Handlers.Player.DroppingItem -= OnDroppingItem;
            Exiled.Events.Handlers.Player.Hurting -= OnHurting;
            Exiled.Events.Handlers.Server.RoundEnded -= OnRoundEnded;
            Exiled.Events.Handlers.Server.RestartingRound -= OnRoundRestarting;

            foreach (var handle in _statusHandles.Values)
            {
                Timing.KillCoroutines(handle);
            }
            _statusHandles.Clear();

            foreach (var player in Player.List)
            {
                if (_rebellionData.TryGetValue(player, out var data) && !string.IsNullOrEmpty(data.OriginalNickname))
                {
                    player.DisplayNickname = data.OriginalNickname;
                }
            }

            _rebellionData.Clear();
            Instance = null;
            Log.Info("Class-D Riot Indicator has been disabled!");
        }

        private void OnPlayerVerified(VerifiedEventArgs ev)
        {
            _rebellionData[ev.Player] = new RebellionData
            {
                OriginalNickname = ev.Player.Nickname
            };
        }

        private void OnPlayerChangingRole(ChangingRoleEventArgs ev)
        {
            if (!_rebellionData.TryGetValue(ev.Player, out var data)) return;

            bool isClassD = ev.NewRole == RoleTypeId.ClassD;
            data.IsClassD = isClassD;

            if (isClassD)
            {
                if (string.IsNullOrEmpty(data.OriginalNickname))
                {
                    data.OriginalNickname = ev.Player.Nickname;
                }

                if (!_statusHandles.ContainsKey(ev.Player))
                {
                    var handle = Timing.RunCoroutine(UpdateRebellionStatus(ev.Player));
                    _statusHandles[ev.Player] = handle;
                }
                UpdateNicknameSuffix(ev.Player, data);
            }
            else
            {
                if (_statusHandles.TryGetValue(ev.Player, out var handle))
                {
                    Timing.KillCoroutines(handle);
                    _statusHandles.Remove(ev.Player);
                }

                if (!string.IsNullOrEmpty(data.OriginalNickname))
                {
                    ev.Player.DisplayNickname = data.OriginalNickname;
                }

                data.RebellionPoints = 0;
                data.HasRebelled = false;
                data.LastSuffix = string.Empty;
            }
        }

        private void OnPlayerDestroying(DestroyingEventArgs ev)
        {
            if (_statusHandles.TryGetValue(ev.Player, out var handle))
            {
                Timing.KillCoroutines(handle);
                _statusHandles.Remove(ev.Player);
            }

            if (_rebellionData.TryGetValue(ev.Player, out var data) && !string.IsNullOrEmpty(data.OriginalNickname))
            {
                ev.Player.DisplayNickname = data.OriginalNickname;
            }

            _rebellionData.Remove(ev.Player);
        }

        private void OnPickingUpItem(PickingUpItemEventArgs ev)
        {
            if (!_rebellionData.TryGetValue(ev.Player, out var data) || !data.IsClassD) return;

            if (_contrabandItems.Contains(ev.Pickup.Type))
            {
                data.RebellionPoints += Instance.Config.PickupContrabandPoints;
                CheckRebellion(ev.Player, data);
                UpdateNicknameSuffix(ev.Player, data);
            }
        }

        private void OnDroppingItem(DroppingItemEventArgs ev)
        {
            if (!_rebellionData.TryGetValue(ev.Player, out var data) || !data.IsClassD) return;

            if (_contrabandItems.Contains(ev.Item.Type))
            {
                // No point reduction for dropping contraband
            }
        }

        private void OnHurting(HurtingEventArgs ev)
        {
            if (ev.Attacker == null || ev.Attacker == ev.Player) return;
            if (!_rebellionData.TryGetValue(ev.Attacker, out var attackerData)) return;

            bool isRebel = attackerData.IsClassD ||
                          ev.Attacker.Role.Team == Team.ChaosInsurgency;

            bool isFoundation = ev.Player.Role.Team == Team.FoundationForces ||
                               ev.Player.Role.Team == Team.Scientists;

            if (isRebel && isFoundation)
            {
                if (attackerData.IsClassD)
                {
                    attackerData.RebellionPoints += Instance.Config.DealDamageToFoundationPoints;
                    CheckRebellion(ev.Attacker, attackerData);
                    UpdateNicknameSuffix(ev.Attacker, attackerData);
                }

                foreach (var player in Player.List)
                {
                    if (player == ev.Attacker) continue;
                    if (!_rebellionData.TryGetValue(player, out var nearbyData)) continue;

                    if (nearbyData.IsClassD && Vector3.Distance(player.Position, ev.Attacker.Position) <= 10f)
                    {
                        nearbyData.RebellionPoints += Instance.Config.NearbyRebelDamagePoints;
                        CheckRebellion(player, nearbyData);
                        UpdateNicknameSuffix(player, nearbyData);
                    }
                }
            }
        }

        private void OnRoundEnded(RoundEndedEventArgs ev)
        {
            foreach (var player in Player.List)
            {
                if (_rebellionData.TryGetValue(player, out var data) && !string.IsNullOrEmpty(data.OriginalNickname))
                {
                    player.DisplayNickname = data.OriginalNickname;
                }
            }

            foreach (var data in _rebellionData.Values)
            {
                data.RebellionPoints = 0;
                data.HasRebelled = false;
                data.LastSuffix = string.Empty;
            }
        }

        private void OnRoundRestarting()
        {
            foreach (var handle in _statusHandles.Values)
            {
                Timing.KillCoroutines(handle);
            }
            _statusHandles.Clear();
        }

        private IEnumerator<float> UpdateRebellionStatus(Player player)
        {
            while (player.IsConnected)
            {
                if (!_rebellionData.TryGetValue(player, out var data))
                {
                    yield return Timing.WaitForSeconds(1f);
                    continue;
                }

                if (!data.HasRebelled)
                {
                    bool hasContraband = player.Items.Any(item => _contrabandItems.Contains(item.Type));

                    bool nearbyContraband = Player.List
                        .Where(p => p != player && p.IsAlive &&
                                  (p.Role.Team == Team.ClassD ||
                                   p.Role.Team == Team.ChaosInsurgency))
                        .Any(p => Vector3.Distance(p.Position, player.Position) <= 10f &&
                                 p.Items.Any(item => _contrabandItems.Contains(item.Type)));

                    if (hasContraband)
                    {
                        data.RebellionPoints += Instance.Config.HoldingContrabandPerSecond;
                    }
                    else if (nearbyContraband)
                    {
                        data.RebellionPoints += Instance.Config.NearbyContrabandPerSecond;
                    }
                    else
                    {
                        data.RebellionPoints = Math.Max(0, data.RebellionPoints - Instance.Config.NoContrabandReductionPerSecond);
                    }

                    CheckRebellion(player, data);
                    UpdateNicknameSuffix(player, data);
                }

                yield return Timing.WaitForSeconds(0.5f);
            }
        }

        private void UpdateNicknameSuffix(Player player, RebellionData data)
        {
            string newSuffix;
            if (data.HasRebelled)
            {
                newSuffix = "[Rioting]";
            }
            else if (data.RebellionPoints >= Config.RebellionThreshold)
            {
                data.HasRebelled = true;
                newSuffix = "[Rioting]";
                player.Broadcast(3, $"Attention Foundation Personnel: D-Class {player.Nickname} has started a riot!");
            }
            else if (data.RebellionPoints < Config.SuspicionThreshold)
            {
                newSuffix = $"({data.RebellionPoints}/200)[Lawful D-Class]";
            }
            else
            {
                newSuffix = $"({data.RebellionPoints}/200)[Suspected Riot]";
            }

            if (data.LastSuffix == newSuffix)
            {
                return;
            }

            data.LastSuffix = newSuffix;

            string newNickname = $"{data.OriginalNickname}{newSuffix}";
            if (newNickname.Length > 31)
            {
                int maxBaseLength = 31 - newSuffix.Length;
                if (maxBaseLength > 0)
                {
                    newNickname = $"{data.OriginalNickname.Substring(0, maxBaseLength)}{newSuffix}";
                }
                else
                {
                    newNickname = newSuffix;
                }
            }

            player.DisplayNickname = newNickname;
        }

        private void CheckRebellion(Player player, RebellionData data)
        {
            if (data.HasRebelled) return;

            if (data.RebellionPoints >= Config.RebellionThreshold)
            {
                data.HasRebelled = true;
                UpdateNicknameSuffix(player, data);

                if (Instance.Config.Debug)
                {
                    Log.Debug($"{player.Nickname} has started a riot!");
                }
            }
        }
    }
}